import java.util.*;
public class rosterOp {

    int stuId=1;
    int teachId=10001;
    int nument;
    ArrayList<Roster>rosLst = new ArrayList<>();

    Scanner read = new Scanner(System.in);

    int printOptions(){
        int choice;

        System.out.println("1.\tCreate a Roster.");
        System.out.println("2.\tModify a Roster.");
        System.out.println("3.\tDelete a Roster.");
        System.out.println("4.\tPrint a Roster.");
        System.out.println("5.\tPrint All Rosters.");
        System.out.println("6.\tSort a Roster");
        System.out.println("7.\tSort all Rosters");
        System.out.println("8.\tEXIT");

        System.out.print("Enter your choice: ");
        choice=read.nextInt();
        return choice;
    }

    void createRoster(){
        String r;
        Roster x = new Roster();
        System.out.print("Enter the Id for roster: ");
        nument = read.nextInt();
        System.out.print("Enter the Name for roster: ");
        r = read.next();
        x.setRosterId(nument);
        x.setRosName(r);
        rosLst.add(x);
        System.out.println("The Roster has been Created.\n");
    }

    void modRoster(){
        Roster x;
        int choice;
        int i;
        int id;

        System.out.print("Enter the Roster id: ");
        id=read.nextInt();

        for(i=0; i<rosLst.size(); i++){
            x=rosLst.get(i);
            if(id == x.getRosterId()){
                System.out.println("\nRoster Found\n");
                System.out.println("1.\tAdd Student.");
                System.out.println("2.\tAdd Teacher.");
                System.out.println("3.\tModify Entry.");
                System.out.println("4.\tDelete Entry.\n");

                System.out.print("Enter your choice: ");
                choice=read.nextInt();

                switch (choice){
                    case 1:
                        x.addEntry(stuId);
                        stuId++;
                        break;
                    case 2:
                        if(x.getflg()<1) {
                            x.addEntry(teachId);
                            teachId++;
                            x.setflg(1);
                        }
                        else
                            System.out.println("There is already a teacher in this Roster.");
                        break;
                    case 3:
                        x.modEntry();
                        break;
                    case 4:
                        x.delEntry();
                        break;
                    default:
                        System.out.println("incorrect entry!");
                        break;
                }
                break;
            }

        }
    }

    void delRoster(){
        Roster x;
        int delId;
        int i;
        System.out.print("Enter the Id of the Roster: ");
        delId=read.nextInt();
        for(i=0;i<rosLst.size();i++){
            x=rosLst.get(i);
            if(x.getRosterId()==delId){
                rosLst.remove(i);
                System.out.println("Roster with given ID deleted!\n");
                break;
            }
        }
    }

    void printRoster(){
        Roster x = new Roster();
        int i;
        int id;

        System.out.print("Enter the Roster id: ");
        id=read.nextInt();

        for(i=0; i<rosLst.size(); i++) {
            x = rosLst.get(i);
            if(id == x.getRosterId()){
                break;
            }
        }

        System.out.println("Roster: " +  x.getRosterId());
        x.printRoster();

    }

    void printAll(){
        Roster x;
        int i;
        for(i=0;i<rosLst.size();i++){
            x=rosLst.get(i);
            x.printRoster();
        }
    }



    void sortRoster(){
        Roster x = new Roster();
        int i, choice;
        int id;

        System.out.print("Enter the Roster id: ");
        id=read.nextInt();

        for(i=0; i<rosLst.size(); i++) {
            x = rosLst.get(i);
            if(id == x.getRosterId()){
                System.out.println("Roster Found\n");
                break;
            }
        }
        System.out.println("1.\tSort Roster by ID.");
        System.out.println("2.\tSort Roster by Age.");

        System.out.print("Enter your choice: ");
        choice=read.nextInt();

        switch (choice) {
            case 1:
                x.sortId();
                break;
            case 2:
                x.sortAge();
                break;
        }
        x.printRoster();

    }

    void sortAll(){
        Roster x;
        int i;
        for(i=0;i<rosLst.size();i++){
            x=rosLst.get(i);
            x.sortId();
            x.printRoster();
        }
    }
}
