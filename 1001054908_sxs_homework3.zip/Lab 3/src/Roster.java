import java.util.*;
public class Roster {

    int rosterId;
    int nument;
    int flg=0;
    int searchpos;
    String charent;
    String rosName;
    ArrayList<Human>lst = new ArrayList<>();
    List<Integer>idchk= new ArrayList<>();

    Scanner read = new Scanner(System.in);

    void setflg(int a){
        flg=a;
    }
    int getflg(){
        return flg;
    }

    void setRosterId(int a){
        rosterId = a;
    }
    void setRosName(String a){
        rosName = a;
    }

    int getRosterId(){
        return rosterId;
    }
    String getrosName(){
        return rosName;
    }

    void addEntry(int a){
        Human x = new Human();
        String nam1, nam2;
        x.setId(a);
        idchk.add(a);

        System.out.print("Enter First Name: ");
        nam1=read.next();
        x.setFName(nam1);

        System.out.print("Enter Last Name: ");
        nam2=read.next();
        x.setLName(nam2);

        System.out.print("Enter Age: ");
        nument=read.nextInt();
        x.setAge(nument);

        lst.add(x);
        System.out.println("Entry added.\n");
    }

    void printRoster(){
        Human z;
        int i;
        System.out.println("======================================");
        System.out.println("Roster Id " + rosterId );
        System.out.println("Roster Name: " + rosName);
        for(i=0; i<lst.size(); i++){
            z=lst.get(i);
            if(z.getId()<10000)
                System.out.println("Student:");
            else
                System.out.println("Teacher:");
            printEntry(z);
        }
        System.out.println("======================================");
    }

    void printEntry(Human z){
        System.out.println("-----------------------------------");
        System.out.println("Id:\t\t\t\t " + z.getId());
        System.out.println("Age:\t\t\t " + z.getAge());
        System.out.println("First Name:\t\t " + z.getFName());
        System.out.println("last Name:\t\t " + z.getLName());
        System.out.println("-----------------------------------");
    }

    boolean idcheck(int a){
        for(int i=0; i<idchk.size(); i++){
            if(idchk.get(i)==a){
                return true;
            }
        }
        return false;
    }

    void modEntry(){
        Human z;
        int modId;
        int choice;
        System.out.print("Enter Id to be modified");
        modId=read.nextInt();
        if(searchEntry(modId)){
            System.out.println("Entry Found! \n");
            z=lst.get(searchpos);
            printEntry(z);
            System.out.println("1.\t Modify ID");
            System.out.println("2.\t Modify Age");
            System.out.println("3.\t Modify First Name");
            System.out.println("4.\t Modify Last Name");
            System.out.print("Enter a choice: ");
            choice=read.nextInt();
            switch (choice){
                case 1:
                    System.out.print("Enter ID: ");
                    nument=read.nextInt();
                    if(idcheck(nument)){
                        System.out.println("This Id already exist");
                        System.out.println("Roster Not Modified\n");
                        break;
                    }
                    else {
                        z.setId(nument);
                        idchk.add(nument);
                        System.out.println("Roster Modified\n");
                    }
                    break;
                case 2:
                    System.out.print("Enter Age: ");
                    nument=read.nextInt();
                    z.setAge(nument);
                    System.out.println("Roster Modified\n");
                    break;
                case 3:
                    String char1;
                    System.out.print("Enter First Name: ");
                    char1=read.next();
                    z.setFName(char1);
                    System.out.println("Roster Modified\n");
                    break;
                case 4:
                    String char2;
                    System.out.print("Enter Last Name: ");
                    char2=read.next();
                    z.setLName(char2);
                    System.out.println("Roster Modified\n");
                    break;
                default:
                    System.out.println("incorrect entry!");
                    break;
            }
            lst.set(searchpos, z);
        }
    }

    void delEntry(){
        Human z;
        int modId;
        char choice;
        System.out.println("Enter Id to be modified");
        modId=read.nextInt();
        if(searchEntry(modId)) {
            System.out.println("Entry Found! \n");
            z = lst.get(searchpos);
            printEntry(z);
            System.out.println("Do You esnt to delete entry? (y/n)");
            choice = read.next().trim().charAt(0);
            if (choice == 'y') {
                lst.remove(searchpos);
            }
        }
    }

    boolean searchEntry(int a) {
        Human z;
        int i;
        for (i = 0; i < lst.size(); i++) {
            z = lst.get(i);
            if (z.getId() == a) {
                searchpos=i;
                return true;
            }
        }
        return false;

    }

    void sortId(){
        Human temp;
        Human x,y;
        int i;
        for(i=0; i<lst.size(); i++){
            for (int j = i; j > 0; j--){
                x=lst.get(j);
                y=lst.get(j-1);
                if(x.getId()<y.getId()){
                    temp=x;
                    x=y;
                    y=temp;
                    lst.set(j, x);
                    lst.set(j-1, y);
                }
            }
        }
    }

    void sortAge(){
        Human temp;
        Human x,y;
        int i;
        for(i=0; i<lst.size(); i++){
            for (int j = i; j > 0; j--){
                x=lst.get(j);
                y=lst.get(j-1);
                if(x.getAge()<y.getAge()){
                    temp=x;
                    x=y;
                    y=temp;
                    lst.set(j, x);
                    lst.set(j-1, y);
                }
            }
        }
    }


}

